#pragma once

#include "string"

enum Types
{
	WEAPON,
	MENU_ENTRY,
	TOGGLE
};

struct MenuEntry
{
	Types type;
	std::string label;
	std::string entityName;
	std::string gotoMenu;
	int id;
	bool needAmmo;
	std::string originalLabel;
	bool toggleActive = false;
};

struct Menus {
	MenuEntry* entries;
};

struct CEntity {
	//todo: pretty much everything
	char field[124];
	float health;
};
