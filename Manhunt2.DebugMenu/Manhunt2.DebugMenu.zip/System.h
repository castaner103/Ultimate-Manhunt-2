#pragma once
#include "stdafx.h"



class System
{
	public:
		static bool KeyHit(unsigned int keyCode);
};

