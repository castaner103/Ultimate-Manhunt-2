#pragma once
#include "CustomStucts.h"
#include "calling.h"

class ManhuntSdk
{

	

	public:

		// the regular mls GetEntity function (return a cloned entity)
		CEntity* GetEntityInstance(const char* name);

		// internal function to get the real entity (without to force a new clone)
		CEntity* GetEntityPointer(const char* name);

		void     CreateInventoryItem(CEntity* ent, int item, bool b1);
		void     AddAmmoToInventoryWeapon(int item, int amount);

		CEntity* GetPlayer();

		void Spawn(int item, bool firearm, const char* record);

		template<typename ...Args>
		void WriteDebug(int line, const char* msg, Args ...args)
		{
			Call<0x53D8D0, int, const char*, Args...>(line, msg, args...);
		}

};

