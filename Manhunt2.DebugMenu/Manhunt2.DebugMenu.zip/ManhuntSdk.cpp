#include "ManhuntSdk.h"


void ManhuntSdk::Spawn(int item, bool firearm, const char* record)
{

	if (GetEntityInstance(record))
	{
		CreateInventoryItem(GetPlayer(), item, true);
		if (firearm == true) AddAmmoToInventoryWeapon(item, 150);
	}
	else WriteDebug(22, "Item does not exist here!");
}

CEntity* ManhuntSdk::GetPlayer()
{
	return *(CEntity * *)0x789490;
}

CEntity* ManhuntSdk::GetEntityInstance(const char* name)
{
	return CallAndReturn<CEntity*, 0x4E9130, const char*>(name);
}

CEntity* ManhuntSdk::GetEntityPointer(const char* name)
{
	return CallAndReturn<CEntity*, 0x4EC530, const char*>(name);
}


void ManhuntSdk::CreateInventoryItem(CEntity* ent, int item, bool b1)
{
	CallMethod<0x4F6500, CEntity*, int, bool>(ent, item, b1);
}

void ManhuntSdk::AddAmmoToInventoryWeapon(int item, int amount)
{
	// using direct player pointer, not any entity
	// as spawner gives stuff to player anwyay
	int v0 = *(int*)(*(int*)0x789490 + 444);
	int v1 = ((int(__thiscall*)(int, int))0x5726F0)(v0, item);

	((void(__thiscall*)(int, int))0x5D2B30)(*(int*)(v1 + 516), amount);
}




